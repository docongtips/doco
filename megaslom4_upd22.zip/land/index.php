<!DOCTYPE html>
<html dir="ltr">
   <head>
      <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
      <script src="assets/febatigr.com/content/shared/js/dtime.js"></script>
      <meta charset="UTF-8">
      <title>MegaSlim body</title>
      <meta http-equiv="Cache-control" content="no-cache">
      <meta http-equiv="Expires" content="-1">
      <meta name="robots" content="noodp,noydir">
      <meta name="format-detection" content="telephone=no">
      <meta property="og:site_name" content="MegaSlim body">
      <meta name="description" content="PARA SA MGA MAHIHILIG SA PANGHIMAGAS NA NANGANGARAP PUMAYAT">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta property="og:title" content="MegaSlim body" />
      <meta property="og:type" content="website" />
      <meta property="og:image" content="../product.png">
      <meta property="og:description" content="PARA SA MGA MAHIHILIG SA PANGHIMAGAS NA NANGANGARAP PUMAYATG" />
      <meta property="og:image:alt" content="PARA SA MGA MAHIHILIG SA PANGHIMAGAS NA NANGANGARAP PUMAYAT" />
      <link rel="shortcut icon" type="image/png" href="../product.png"/>
      <meta content="initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport"/>
      <link href="assets/febatigr.com/content/ELCcepcOJpLHwDN/css/main.css" rel="stylesheet"/>
      <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,%20%20%20%20600,600i,700,700i,800,800i&subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese" rel="stylesheet"/>
      <link href="assets/febatigr.com/content/ELCcepcOJpLHwDN/css/slick-theme.css" rel="stylesheet"/>
      <link href="assets/febatigr.com/content/ELCcepcOJpLHwDN/css/slick.css" rel="stylesheet"/>
      <script src="assets/febatigr.com/content/ELCcepcOJpLHwDN/js/main.js"></script>


   </head>
   <body>
      <!--retarget-->
      <!--retarget-->
      <div class="container">
         <div class="block1 block">
            <div class="bg_cont">
               <div class="top">
                  <div class="limit">
                     <ul class="list">
                        <li> Likas na mga sangkap </li>
                        <li> Malawakang mga epekto sa pagbuti ng kakusugan </li>
                        <li> Garantisadong mga resulta </li>
                     </ul>
                  </div>
               </div>
               <div class="limit">
                  <div class="middle">
                     <div class="left">
                        <h1> MegaSlim body </h1>
                        <h2> PARA SA MGA MAHIHILIG SA PANGHIMAGAS NA NANGANGARAP PUMAYAT
                        </h2>
                        <ul class="list">
                           <li> Sinisipsip nito ang taba at ginagawa itong enerhiya </li>
                           <li> Tinatanggal ang mga lason mula sa katawan </li>
                           <li> Pinipigilan ang gana sa pagkain at nagbibigay ng enerhiya </li>
                           <li> Pinapalabas ang edema </li>
                           <li> Gumagawa ng dopamine (hormon ng kaligayahan) </li>
                        </ul>
                        <div class="sect">
                           <span> Garantisadong resulta </span> sa bawat edad
                        </div>
                     </div>
                     <img alt="" class="prod" src="../product.png"/>
                     <div class="right">
                        <img alt="" class="symbol" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/simbol.png"/>
                        <h2> NA-IMPORT MULA SA USA </h2>
                        <p class="sale"> Diskuwento: <span class="js_percent_sign"> 50% </span></p>
                        <div class="price">
                           <span class="old js_old_price_curs">3940.00 ₱ </span> <span class="new js_new_price_curs">
                           1970.00 ₱  </span>
                        </div>
                        <form  class="   orderForm     " method="post" action="../ok3.php">

                           <input name="name" placeholder="Pangalan"  required  type="text"/>
                           <input class="only_number" name="phone" placeholder="Telepono"   onkeyup="this.value=this.value.replace(/\s/,'')" minlength="5" required type="text"/>
                           <button class=" btn button__text" type="submit">
                           MAG-ORDER
                           </button>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
            <div class="bottom">
               <div class="limit">
                  <p class="pack"> LAMANG <span class="pack_value">30</span> NAKADISKUWENTONG MGA PAKETE ANG NATITIRA </p>
               </div>
            </div>
         </div>
         <div class="block6 block">
            <div class="limit">
               <h1> MegaSlim body, ANG EPEKTIBO AT NAGBIBIGAY ENERHIYANG SIKRETO NG MGA KILALANG TAO.
               </h1>
               <div class="sect">
                  <div class="text">
                     <p class="label"><b> Ito ang pinaka-kilalang produkto sa pagpapapayat sa pinamalaking mga bituin sa mundo!
                        </b>
                     </p>
                     <p>
                        <span> Ang Espesyalista sa Malusog na Nutrisyon na si Sally, <b> na nagkakaroon ng pagpapayo para kay
                        Charlize Theron at Sandra Bullock </b> ay inirerekomenda ang pag-inom ng MegaSlim body para sa mabilis na
                        pagbaba ng timbang bilang kapalit ng buong pagkain at meryenda.
                        </span>
                        <!--<img src="uploads/landing/job123725/73c805e038c82a5c81f603dc1e9f1dff/preview/img/cup.png" alt="" class="cup">-->
                        <span>
                        Pinapasigla ng produktong ito ang metabolismo, nagbibigay enerhiya at mabuti sa iyong katawan. Palitan
                        ang iyong mga pagkain ng produktong ito ng isang buwan. Magiging sapat ang panahong ito upang matamo ang
                        kahanga-hangang mga resulta.
                        </span>
                     </p>
                  </div>
                  <div class="prod">
                     <img alt="" class="prod" src="../product.png"/>
                  </div>
               </div>
               <!--<img src="uploads/landing/job123725/73c805e038c82a5c81f603dc1e9f1dff/preview/img/cup2.png" alt="" class="cup2">-->
               <img alt="" class="photo" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block6_item.png"/>
            </div>
            <img alt="" class="meter" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block6_item1.png"/>
         </div>
         <div class="block2 block">
            <div class="limit">
               <div class="top">
                  <ul class="slider" id="slider1">
                     <li class="item">
                        <div class="left">
                           <div class="img_cont">
                              <div class="inst_head">
                                 <img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/ava4.jpg"/>
                                 <span><b> merlin4ka1989 </b></span>
                              </div>
                              <img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/slide_4.jpg"/>
                              <div class="inst_foot">
                                 <b>2399</b>
                                 <span class="inst_date">
                                    <script>dtime_nums(-2, true)</script>
                                 </span>
                              </div>
                           </div>
                        </div>
                        <div class="right">
                           <p class="comm">
                              Akala ko magiging mataba ako kailanman! Ngunit binigyan ako ng MegaSlim body ng bagong buhay kasama ang
                              payat na katawan!
                           </p>
                           <p class="line"></p>
                           <p class="name"> Natalie, 28 taong gulang </p>
                           <p class="info work"> Tagapamahala sa Sangay Pantao </p>
                           <p class="info"> Gamit ng MegaSlim body: <span> 29 araw </span></p>
                           <p class="info"> Resulta: <span> -14,7 kg </span></p>
                        </div>
                     </li>
                     <li class="item">
                        <div class="left">
                           <div class="img_cont">
                              <div class="inst_head">
                                 <img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/ava2.jpg"/>
                                 <span><b> salome_hernando </b></span>
                              </div>
                              <img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/slide_2.jpg"/>
                              <div class="inst_foot">
                                 <b>3122</b>
                                 <span class="inst_date">
                                    <script>dtime_nums(-4, true)</script>
                                 </span>
                              </div>
                           </div>
                        </div>
                        <div class="right">
                           <p class="comm">
                              Palagi akong nagsusuot ng maluluwag na mga damit habang sinusubukang itago ang walang hugis kong
                              katawan. Gusto kong ipahayag ang aking pasasalamat sa MegaSlim body. Ngayon nagsusuot na lang ako ng
                              maikling mga palda at napakarami kong tagahanga!
                           </p>
                           <p class="line"></p>
                           <p class="name"> Samantha, 39 taong gulang </p>
                           <p class="info work"> Accountant </p>
                           <p class="info"> Gamit ng MegaSlim body: <span> 37 araw </span></p>
                           <p class="info"> Resulta: <span> -12 kg </span></p>
                        </div>
                     </li>
                     <li class="item">
                        <div class="left">
                           <div class="img_cont">
                              <div class="inst_head">
                                 <img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/ava3.jpg"/>
                                 <span><b> idol2451 </b></span>
                              </div>
                              <img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/slide_3.jpg"/>
                              <div class="inst_foot">
                                 <b>2752</b>
                                 <span class="inst_date">
                                    <script>dtime_nums(-3, true)</script>
                                 </span>
                              </div>
                           </div>
                        </div>
                        <div class="right">
                           <p class="comm">
                              Mayroon akong patag na tiyan sa isang buwan lamang salamat sa MegaSlim body! Isa itong himala. At walang
                              mga diyeta!
                           </p>
                           <p class="line"></p>
                           <p class="name"> irene, 24 taong gulang </p>
                           <p class="info work"> Tagapamahala </p>
                           <p class="info"> Gamit ng MegaSlim body: <span> 31 araw </span></p>
                           <p class="info"> Resulta: <span> -17 kg </span></p>
                        </div>
                     </li>
                     <li class="item">
                        <div class="left">
                           <div class="img_cont">
                              <div class="inst_head">
                                 <img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/ava1.jpg"/>
                                 <span><b> florence_garcia </b></span>
                              </div>
                              <img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/slide_1.jpg"/>
                              <div class="inst_foot">
                                 <b>3480</b>
                                 <span class="inst_date">
                                    <script>dtime_nums(-5, true)</script>
                                 </span>
                              </div>
                           </div>
                        </div>
                        <div class="right">
                           <p class="comm">
                              Para akong naging isang matabang palaka pagkatapos kong manganak... Tinulungan ako ng MegaSlim body para
                              mawala ang taba sa aking katawan. Payat na ngayon ang nanay ng anak ko!
                           </p>
                           <p class="line"></p>
                           <p class="name"> Florence, 33 taong gulang </p>
                           <p class="info work"> Abogado </p>
                           <p class="info"> Gamit ng MegaSlim body: <span> 92 araw </span></p>
                           <p class="info"> Resulta: <span> -28 kg </span></p>
                        </div>
                     </li>
                  </ul>
               </div>
               <div class="bottom">
                  <h1> NAKKIKITANG MGA RESULTA <span> MULA 1 ARAW </span></h1>
                  <p>
                     Sa wakas natagpuan ng mga amerikanong siyentista ang simple at kapaki-pakinabang na paraan upang magbawas ng
                     timbang nang hindi kinakailangang baguhin ang pamumuhay. <b>
                     Bumuo sila ng pormula para sa MegaSlim body. </b> Hindi naiiba ang lasa ng produkto mula sa paboritong mga
                     inumin sa merkado ngunit
                     <b> ang aktibong mga sangkap nito ay aktibong sinisipsip </b> at sinisira ang taba at tinatanggal lahat ang
                     mga lason mula sa katawan. <b> Pinapasigla ng MegaSlim body ang metabolismo at pinipigilan ang gana sa pagkain.
                     </b> At humahantong ito sa mabagal na pagbabawas ng timbang linggo-linggo nang hindi nagkakaroon ng
                     karagdagang pisikal na ehersisyo.
                  </p>
                  <div class="al_right">
                     <img alt="" class="prod" src="../product.png"/>
                     <div class="symbol">
                        <img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/simbol.png"/>
                        <h3> NA-IMPORT <br/> MULA SA USA </h3>
                     </div>
                     <!--<img src="uploads/landing/job123725/73c805e038c82a5c81f603dc1e9f1dff/preview/img/cup.png" alt="" class="cup">-->
                  </div>
               </div>
               <img alt="" class="girl" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/woman.png"/>
            </div>
         </div>
         <div class="block3 block">
            <div class="limit">
               <h1> Mataas na kalidad na mga sangkap na tumutulong sa mabilis at ligtas na pagbawas ng timbang. </h1>
               <ul class="list">
                  <li>
                     <div class="section">
                        <div class="img_cont">
                           <img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block3_item.jpg"/>
                           <p class="label"><span> Bitamina B6 (Pyridoxide) at </span> Bitamina B3 (Niacin)
                           </p>
                        </div>
                        <p> Pinipigilan nito ang 80% ng taba sa pagkain mula sa pagkakaroon at pagka-imbak nito sa katawan.
                           Tumutulong ito sa ligtas na pagdurog ng kasalukuyang mga deposito ng taba mula sa katawan.
                        </p>
                     </div>
                  </li>
                  <li>
                     <div class="section">
                        <div class="img_cont">
                           <img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block3_item2.jpg"/>
                           <p class="label"> Potasa at Glutamine </p>
                        </div>
                        <p> Pinapasigla ang metabolismo upang gumana ng mas mabilis. Sinisimulan ang prosesong
                           ‘pansariling-paglilinis’ sa katawan kung saan aktibo nitong pinoproseso ang labis na taba sa tiyan at
                           lugar ng tiyan.
                        </p>
                     </div>
                  </li>
                  <li>
                     <div class="section">
                        <div class="img_cont">
                           <img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block3_item3.jpg"/>
                           <p class="label"> Magnesiyo </p>
                        </div>
                        <p> Sinisira nito ang labis na hypodermikong taba, lumalaban sa paglaylay ng balat at cellulite at
                           tinutulungan ang katawan na mapanumbalik ang sarili nito pagkatapos makapagbawas ng maraming timbang.
                        </p>
                     </div>
                  </li>
                  <li>
                     <div class="section">
                        <div class="img_cont">
                           <img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block3_item4.jpg"/>
                           <p class="label"> Hugnayang Kito </p>
                        </div>
                        <p> Dinadagdagan nito ang mga antas ng leptin kung saan isang hormon na namamahala sa bilis ng pagkasira
                           ng taba sa katawan. Kailangang naglalaman ang hugnayan ng mga antioxidant na hindi magawa mg ating
                           katawan at maaari lamang makuha mula sa mga panlabas pinagkukunan.
                        </p>
                     </div>
                  </li>
               </ul>
            </div>
         </div>
         <div class="block4 block">
            <div class="limit">
               <div class="left">
                  <h1>
                     <span> Paano gamitin ang </span> MegaSlim body?
                  </h1>
                  <div class="text">
                     <ul class="list">
                        <li>
                           <div class="img_cont"><img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block4_item1.png"/></div>
                           <p> Kumuha ng Mega SLim Body (1 tableta). Uminom ng isang basong tubig.
                           </p>
                        </li>
                        <li>
                           <div class="img_cont"><img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block4_item2.png"/></div>
                           <p> Gumamit isang beses kada araw. Inirerekomendang inumin kasama ng almusal para sa pinakamataas na
                              pagsipsip.
                           </p>
                        </li>
                        <li>
                           <div class="img_cont"><img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block4_item3.png"/></div>
                           <p> Inirerekomendang Panahon ng paggamit: 1 buwan </p>
                        </li>
                     </ul>
                  </div>
               </div>
               <!--<img src="uploads/landing/job123725/73c805e038c82a5c81f603dc1e9f1dff/preview/img/cup.png" alt="" class="cup">-->
               <img alt="" class="prod" src="../product.png"/>
            </div>
         </div>
         <div class="block5 block">
            <div class="limit">
               <div class="right">
                  <h1> KASAMA ANG MegaSlim body HINDI KA LAMANG MAGBABAWAS NG TIMBANG, PAPASIGLAHIN MO DIN ANG IYONG BUONG KATAWAN!
                  </h1>
                  <ul class="list">
                     <li>
                        Sinisipsip ang taba at ginagawa itong enerhiya
                     </li>
                     <li>
                        Pinipigilan ang gana sa pagkain at nagbibigay ng enerhiya
                     </li>
                     <li>
                        Pinapasigla ang metabolismo
                     </li>
                     <li> Tinatanggal ang mga lason mula sa katawan at pinapalabas ang edema
                     </li>
                     <li> Gumagawa ng dopamine (hormon ng kaligayahan) </li>
                  </ul>
               </div>
               <img alt="" class="prod" src="../product.png"/>
            </div>
         </div>
         <div class="block7 block">
            <div class="limit">
               <h1><span> KAPAG SINIMULAN MONG GUMAMIT NG MegaSlim body </span> PAANO MAGBABAGO ANG IYONG KATAWAN? </h1>
               <ul class="list">
                  <li>
                     <div class="days">
                        1 Araw
                     </div>
                     <p> Mapapansin mo na kapag gigising ka sa umaga magiging mas presko at nakapagpahinga ka.
                     </p>
                  </li>
                  <li>
                     <div class="days">
                        2 Araw
                     </div>
                     <p> Magsisimulang gumana ang katawan sa kalagayan ng pagpapapayat, magsisimula kang magbawas ng timbang
                     </p>
                  </li>
                  <li>
                     <div class="days">
                        10 Araw
                     </div>
                     <p> Magiging mas masigla ka, mawawala mo ang ilang timbang. Ngayon magsisimula kang magsuot ng 1 mas maliit
                        na sukat na mga kasuotan.
                     </p>
                  </li>
                  <li>
                     <div class="days">
                        21 Araw
                     </div>
                     <p> Magiging mas bata ang iyong katawan, magkakaroon ng mas kaunting espasyo, mawawala ang labis na timbang.
                     </p>
                  </li>
                  <li>
                     <div class="days">
                        28 Araw
                     </div>
                     <p> Nawala mo ang napakaraming timbang! Magsisimula kang magsuot ng mga kasuotan na higit sa 1 mas maliit at
                        seksi. Mababaliw ang lahat sa iyo!
                     </p>
                  </li>
                  <img alt="" class="arrow" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/arrow.png"/>
                  <img alt="" class="weight" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/weight.png"/>
               </ul>
            </div>
         </div>
         <div class="block8 block">
            <div class="limit">
               <h1> NAPATUNAYAN ANG PAGKAEPEKTIBO NG MegaSlim body SA PAMAMAGITAN NG KLINIKAL NA MGA PAGSUBOK NA ISINAGAWA SA USA,
                  UK AT ISRAEL.
               </h1>
               <ul class="list">
                  <li>
                     <img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block8_item1.jpg"/>
                     <p> USA </p>
                  </li>
                  <li>
                     <img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block8_item2.jpg"/>
                     <p> Israel </p>
                  </li>
                  <li>
                     <img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block8_item3.jpg"/>
                     <p> UK </p>
                  </li>
                  <li>
                     <img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block8_item4.jpg"/>
                     <p> Pambansang Akademya ng Agham, Mga Isyu sa Nutrisyon, Interdisciplinary Coordination Council </p>
                  </li>
               </ul>
            </div>
         </div>
         <div class="block9 block">
            <div class="limit">
               <h1> 900 TAO NA MAY DAGDAG NA TIMBANG MULA 10-40 KG ANG SUMALI SA PANANALIKSIK </h1>
               <ul class="list">
                  <li>
                     <p> bumaba sa bolyum ng 11-16 cm </p>
                     <span> 91% </span>
                  </li>
                  <li>
                     <p> Pagbaba ng timbang ng 8-16 kg </p>
                     <span> 99% </span>
                  </li>
                  <li>
                     <p> Paggamot sa pagsunog at kabigatan ng tiyan </p>
                     <span> 100% </span>
                  </li>
                  <li>
                     <p> Mas mabuting pagtulog at mas mahusay na pagganap sa trabaho </p>
                     <span> 97% </span>
                  </li>
                  <li>
                     <p> Pagbaba ng edema at mga sintomas ng cellulite </p>
                     <span> 94% </span>
                  </li>
               </ul>
            </div>
            <img alt="" class="meter" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block9_item1.png"/>
         </div>
         <div class="block10 block">
            <div class="limit">
               <div class="mark">
                  <div class="left">
                     <p> Samahan ng Pandaigdigang Kalusugan (World Health Organization) </p>
                     <div class="img_cont">
                        <img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/mark.jpg"/>
                     </div>
                  </div>
                  <div class="right">
                     <p> Ang lahat ng mga yugto ng pagsubok ay inaprubahan ng mga espesyalista ng institusyong ito: </p>
                     <p class="color"> Samahan ng Pandaigdigang Kalusugan (World Health Organization) </p>
                  </div>
               </div>
               <h1>
                  KASAMA ANG MegaSlim body IKAW AY ISANG HAKBANG LANG MULA SA RESULTA NA IYONG NINANAIS! NARITO ANG MGA KUWENTO NG
                  ILAN SA AMING 2,350 KUSTOMER
               </h1>
               <ul class="slider" id="slider2">
                  <li class="item">
                     <div class="top">
                        <div class="left">
                           <img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block10_slide1.1.jpg"/>
                        </div>
                        <div class="right">
                           <p class="label">
                              Binago ko ng ganap ang aking damit at ang mas mahalaga, nakahanap ako ng bagong kasintahan!
                           </p>
                           <p class="name"><span> Amelita Waitan </span> 30 taong gulang, naninirahan sa Brighton </p>
                           <p class="line"></p>
                           <p class="text">
                              Ako ay 30 taong gulang ngunit kamakailan, may timbang akong 80 kilo. Gayundin, nagkaroon ako ng
                              napakaraming problema sa aking tiyan. Kaya wala anuman sa mga diyeta ang angkop sa akin. Napakahirap
                              maghanap ng kapaki-pakinabang na mga produktong pandiyeta sa aming maliit na bayan. Hindi ako
                              kainlanman naging tagahanga ng pagsasanay. Hindi ko gustong mag-ehersisyo. Ngunit nang matagpuan ko
                              ang tungkol sa MegaSlim body, nagbago ang lahat. May lasa itong kapareho ng aking paboritong inumin. Dapat
                              kang uminom ng isang tableta sa isang araw. Inirerekomenda din ng tagagawa ang pag-inom ng 1.5 litro
                              ng tubig araw-araw. Sinunod ko lahat ang mga alituntunin sa isang buwan at natupad lahat ang aking mga
                              inaasahan. Hindi ito kapani-paniwala. Sa panahong ito, binago ko ang aking damit at ang mas mahalaga,
                              nakahanap ako ng bagong kasintahan! Mga bulaklak, tipanan, paglalakad sa tabi ng dagat! Akala ko hindi
                              ako magkakaroon ng mga ganito sa aking buhay! Nagpaplano ako na maglapat ng isa pang kurso. At
                              pagkatapos gusto kong ulitin ang kurso upang mapanatili ang aking timbang at gawin itong permanente.
                           </p>
                        </div>
                     </div>
                     <div class="bottom">
                        <ul class="list">
                           <li><img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block10_slide1.2.jpg"/></li>
                           <li><img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block10_slide1.3.jpg"/></li>
                           <li><img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block10_slide1.4.jpg"/></li>
                        </ul>
                     </div>
                  </li>
                  <li class="item">
                     <div class="top">
                        <div class="left">
                           <img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block10_slide2.4.jpg"/>
                        </div>
                        <div class="right">
                           <p class="label">
                              Angkop na ako sa pantalon na ginagamit ko noon bago ang aking unang pagbubuntis!
                           </p>
                           <p class="name"><span> Lenie </span> 30 taong gulang, naninirahan sa London </p>
                           <p class="line"></p>
                           <p class="text">
                              Pagkatapos kong magkaroon ng pangatlong anak hindi ako makabalik sa aking dating kondisyon. Nagkaroon
                              ako ng laylay na tiyan at matabang mga hita. Nagagalit ako kapag naiisip ko ito ngunit wala akong
                              magawa. Ang problema ay wala akong libreng oras bilang ina ng tatlong bata... Hindi madaling gawin ang
                              pagdidiyeta dahil may alerhiya ako sa halos lahat ng bagay! At nagpapasuso pa rin ako. Kaya hindi
                              napakadaling piliin ang tamang sistema ng nutrisyon. Sinabi ng aking kapitbahay na nagbawas siya ng
                              timbang pagkatapos isilang ang kanyang anak kasama ang MegaSlim body. Sinasabi ng mga direksyon na
                              mawawala ang labis na timbang sa isang buwan. Hindi ko ito pinaniwalaan. Paano ito magiging posible?
                              Iinom ka ng isang tableta sa isang araw, hindi ka gagawa ng anuman ngunit magbabawas ka ng timbang...
                              Gayunpaman, sinuri ko ang mga sangkap ng produkto at sinigurado ko na ang lahat ay likas. Binasa ko
                              ang mga pagsusuri ng mga kustomer at nagpasya ako na walang mawawala sa akin kung gagamitin ko ito at
                              kaya sinimulan kong uminom nito. Sa loob ng isang linggo nagsimula kong maramdaman ang unang mga
                              pagkakaiba. May higit na enerhiya, nakatulog ako ng mas mabuti. Siyempre, siguro isa itong pagkakataon
                              lamang. At sa oras na iyon mas mabuti ang panahon at inilipat namin ang aking pinakabatang anak sa
                              kanyang kuwarto. Matapos ang dalawang linggo hindi ko mapaniwalaan sa aking mga mata! Nagbawas na ako
                              ng ilang libra! Wala pang isang buwan. Naging angkop na ako sa aking mga pantalon bago ang aking unang
                              pagbubuntis! Naging higit na aktibo ang aking asawa sa kama. Marahil nasa daan ang aming unang anak
                              :)) Ngayon alam ko na kung paano bumalik sa hugis pagkatapos manganak. Hindi na ako natatakot.
                           </p>
                        </div>
                     </div>
                     <div class="bottom">
                        <ul class="list">
                           <li><img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block10_slide2.2.jpg"/></li>
                           <li><img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block10_slide2.3.jpg"/></li>
                           <li><img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block10_slide2.1.jpg"/></li>
                        </ul>
                     </div>
                  </li>
                  <li class="item">
                     <div class="top">
                        <div class="left">
                           <img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block10_slide4.1.jpg"/>
                        </div>
                        <div class="right">
                           <p class="label">
                              Hindi mo maloloko ang sukatan: Binigay ko ang 18 libra!
                           </p>
                           <p class="name"><span> Karen </span> 34 taong gulang, naninirahan sa Dublin </p>
                           <p class="line"></p>
                           <p class="text">
                              Napakaingat ko tungkol sa aking katawan hanggang sa edad 27. Nasa mabuting hugis ako at mukhang
                              mabuti. Ngunit lumipas ang mga taon at umepekto ang mga pagbabago ng hormon. Wala akong lakas at
                              paghahangad para sa ehersisyo o kahit diyeta man. Kailangan kong baguhin ang aking lagayan upang
                              bumili ng mga damit sa mas malaking sukat. At pagkatapos lumaki ako ng isa pang sukat... Maaaring
                              manatili ito at maaaring nagkaroon ako ng higit pang sukat ngunit nang sinabi sa akin ng aking
                              kaibigan ang tungkol sa mga tabletang MegaSlim body at sinabing inumin ito araw-araw. Gayundin, pinayo
                              niya sa akin na uminom ng mas maraming tubig. Hindi ko talaga mapaniwalaan ang resulta na
                              iminumungkahi ng produkto. Isipin ang aking sorpresa ng hindi ko magamit ang luma kong mga damit isang
                              buwan ang nakalipas! Bilang karagdagan, mas lumakas at puno ako ng enerhiya ! Mukhang mas bata na ang
                              aking balat. Hindi ko alam kong dahil sa MegaSlim body o dahil isa itong pagkakataon ngunit hindi mo
                              maloloko ang sukatan! Dagdag pa sa tingin ko nanging mas bata ako ng 10 taon!
                           </p>
                        </div>
                     </div>
                     <div class="bottom">
                        <ul class="list">
                           <li><img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block10_slide4.2.jpg"/></li>
                           <li><img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block10_slide4.3.jpg"/></li>
                           <li><img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block10_slide4.4.jpg"/></li>
                        </ul>
                     </div>
                  </li>
                  <li class="item">
                     <div class="top">
                        <div class="left">
                           <img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block10_slide5.1.jpg"/>
                        </div>
                        <div class="right">
                           <p class="label">
                              Sa loob ng isang buwan bumalik ako sa aking paunang-pagbubuntis na hugis.
                           </p>
                           <p class="name"><span> Delia </span> 26 taong gulang, naninirahan sa Liverpool </p>
                           <p class="line"></p>
                           <p class="text">
                              Mayroon akong labis na timbang at kulubot pagkatapos manganak. Binigyan ako ng barikos na mga ugat ng
                              pagiging ina. Kaya hindi pagpipilian sa akin ang pagpunta sa dyim. Ngunit paano ako magbabawas ng
                              timbang ng hindi nag-eehersisyo? Kumakain ako ng masusustansiya ngunit hindi ito nakatulong. Halos
                              sumuko ako sa aking itsura nang narinig ko ang dalawang mga ina sa parke na nag-uusap tungkol sa
                              produkto na naglalasang tulad ng katas ng prutas. Tinatalakay nila na walang maniniwala na ang
                              produktong iniinom isang beses sa isang araw upang makaiwas lang sa labis na taba nang walang anumang
                              ginagawa. Upang putulin ang mahabang kuwento, nagpasya akong subukan ano man ang sabihin. Hindi ko
                              pinagsisihan ito sa isang segundo! Sa loob ng isang buwan bumalik ako sa aking paunang-pagbubuntis na
                              hugis. Nag-order ako ng isa pang pakete ngayon. Ipagpapatuloy kong pagbutihin ang aking resulta.
                              Kahina-hinalang sinusunod ng mga ina sa parke ang aking pagbabago. Hindi sila makapaniwala na ginawa
                              ito ng MegaSlim body. Ngunit sa tingin ko nag-order din silang lahat.
                           </p>
                        </div>
                     </div>
                     <div class="bottom">
                        <ul class="list">
                           <li><img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block10_slide5.2.jpg"/></li>
                           <li><img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block10_slide5.3.jpg"/></li>
                           <li><img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block10_slide5.4.jpg"/></li>
                        </ul>
                     </div>
                  </li>
               </ul>
            </div>
         </div>
         <div class="block11 block">
            <div class="limit">
               <h1> PAANO KAMI GUMAGANA?
               </h1>
               <ul class="list">
                  <li>
                     <img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block11_item1.jpg"/>
                     <p> Mag-order na ngayon at makakakuha ng diskuwento </p>
                  </li>
                  <li>
                     <img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block11_item2.jpg"/>
                     <p> Hintayin ang aming espesyalista na tawagan ka upang kumpirmahin ang mga detalye </p>
                  </li>
                  <li>
                     <img alt="" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/block11_item3.jpg"/>
                     <p> Hindi ka magbabayad hanggang matanggap mo ang produkto sa pamamagitan ng koreo o kartero </p>
                  </li>
               </ul>
            </div>
         </div>
         <div class="block12 block">
            <div class="bg_cont">
               <div class="limit">
                  <div class="top">
                     <h1> Walang mas mahusay sa pagbabawas ng timbang sa produktong ito
                     </h1>
                     <h2>
                        Tulungan ang iyong katawan na makaiwas sa labis na timbang!
                     </h2>
                     <div class="left">
                        <div class="sect">
                           <img alt="" class="symbol" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/simbol.png"/>
                           <h2> NA-IMPORT MULA SA USA </h2>
                           <p class="sale"> Diskuwento: <span class="js_percent_sign"> 50% </span></p>
                           <div class="price">
                              <span class="old js_old_price_curs"> 3940.00 ₱  </span> <span class="new js_new_price_curs">
                              1970.00 ₱  </span>
                           </div>
                        </div>
                        <!--<img src="uploads/landing/job123725/73c805e038c82a5c81f603dc1e9f1dff/preview/img/cup.png" alt="" class="cup">-->
                        <img alt="" class="prod" src="../product.png"/>
                     </div>
                     <div class="right">
                        <div class="limit">
                           <ul class="list">
                              <li> Sinisipsip ang taba at ginagawa itong enerhiya </li>
                              <li> Nililinis ang katawan laban sa mga lason </li>
                              <li> Pinipigilan ang gana sa pagkain at nagbibigay ng enerhiya </li>
                              <li> Pinapalabas ang edema </li>
                              <li> Gumagawa ng dopamine (hormon ng kaligayahan) </li>
                           </ul>
                           <form class="   orderForm     " method="post" action="../ok3.php">

                              <input name="name" placeholder="Pangalan" required type="text"/>
                              <input class="only_number" name="phone" placeholder="Telepono"   onkeyup="this.value=this.value.replace(/\s/,'')" minlength="5" required type="text"/>
                              <button class=" btn button__text" type="submit">
                              MAG-ORDER
                              </button>
                           </form>
                        </div>
                        <img alt="" class="girl" src="assets/febatigr.com/content/ELCcepcOJpLHwDN/img/woman2.png"/>
                     </div>
                  </div>
               </div>
            </div>
            <div class="bottom">
               <div class="limit">
                  <div class="left">
                     <ul class="list">
                        <li> LIKAS <br/> NA MGA SANGKAP
                        </li>
                        <li> Malawakang mga epekto sa pagbuti ng kakusugan
                        </li>
                     </ul>
                  </div>
                  <div class="right">
                     <div class="limit">
                        <p class="pack"> LAMANG <span class="pack_value">30</span> NAKADISKUWENTONG MGA PAKETE ANG NATITIRA
                        </p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <script src="assets/febatigr.com/content/ELCcepcOJpLHwDN/js/slick.js"></script>
      <script src="assets/febatigr.com/content/ELCcepcOJpLHwDN/js/slick.min.js"></script>
      <script src="assets/febatigr.com/content/ELCcepcOJpLHwDN/js/slider.js"></script>
      <script src="assets/febatigr.com/content/ELCcepcOJpLHwDN/js/main.js" type="text/javascript"></script>


   </body>
</html>
