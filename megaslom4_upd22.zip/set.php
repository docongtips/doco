<?php

$pixel = '';
